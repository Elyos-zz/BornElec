# BornElec
Dans le cadre de l'évalutation de os compétences en développement d'application mobiles, nous avons choisi de développer le projet BornElec.
BornElec est le nom de l'appication que nous allons essayé de développer. Une application a but non commercial, permettant aux utilisateurs de ressensé l'ensemble de toute les bornes autolib de France.
Permettant ainsi aux utilisateurs de connaître l'emplacement des bornes aisni que leurs caractéristiques.
