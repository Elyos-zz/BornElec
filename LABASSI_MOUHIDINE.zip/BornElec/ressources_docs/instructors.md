
#Instructions
Exemple application qui utilise une asynctask en chargeant une maps avec des ¨picks
http://javapapers.com/android/find-places-nearby-in-google-maps-using-google-places-apiandroid-app/

Exemple lecture fichier csv et parse to un arrayList :
https://stackoverflow.com/questions/38415680/how-to-parse-csv-file-into-an-array-in-android-studio


/*
 * 29-07-2017 N.MOUHIDINE
 */

# Test lecturefichier csv
# Affichage trop long pour la taille de l'écran
# Mode landscape possibilité d'afficher id_station et nom_station

+ CSVFile.java # classe utilitaire permettant de lire notre fichier CSV
+ ItemArrayAdapter.java # classe permettant de contenir l'ensemble des données CSV à afficher dans la ListView
+ item_layout.xml # XML de mise en page de l'application 'Vue des données du CSV'
+ etat_avancement.JPG # capture d'écran de la situation actuelle
+ Push version pseudo finale
+ Développement AsyncTask